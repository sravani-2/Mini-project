import { Component } from '@angular/core';
import { Product } from './product';
import { ProductService } from './app.productservice'

@Component({
    selector: 'product-app',
    templateUrl: './app.product.html',
    styleUrls: ['./app.product.css'],
    providers: [ProductService]
})

export class ProductComponent {

    p: number = 1;
    model: any = {};
    up: any = {};
    Products: Product[];
    constructor(private getAllProducts: ProductService) { }   //DI
    ngOnInit(): any {
        this.getAllProducts.getAllProducts().subscribe((data: Product[]) => this.Products = data);
    }

    addDetails(): any {

        var reg=/^[a-z]+$/;
        var reg1=/^[0-9]+$/;
    
        if(this.model.Price.match(reg)){
            alert("price should be a numeric value");
        }
        else if(this.model.id.match(reg)){
            alert("id should be a numeric value");
        }
        else if(this.model.Name.match(reg1)){
            alert("name should not be a numeric value");
        }
        else if(this.model.Description.match(reg1)){
            alert("description should not be a numeric value");
        }
        else if(this.model.id=="" || this.model.Name=="" || this.model.Description=="" || this.model.Price==""){
              alert("Enter the values");
        }
        else{
            alert("Item added");
            this.Products.push(this.model)
            this.model = {};
        }

       
    }


    update(eid: number): any {
       
        for (let i in this.Products) {
            if (this.Products[i].id == eid) {
                this.up = this.Products[i];
            
        }

        }
    }

    updatenew(): any {
        this.up.id = (document.getElementById("a") as HTMLInputElement).value;
        this.up.Name = (document.getElementById("b") as HTMLInputElement).value;
        this.up.Description = (document.getElementById("c") as HTMLInputElement).value;
        this.up.Price = (document.getElementById("d") as HTMLInputElement).value;

        this.up = {}
    }

    delete(eid: number): any {
        if (confirm("Are you sure you want to delete data?")) {
            for (let i in this.Products) {

                if (this.Products[i].id == eid) {
                    this.Products.splice(Number(i), 1);
                }

            }
        }
    }

    deleteAll(): any {

        if (confirm("Are you sure you want to delete data?")) {
        this.Products.splice(0, this.Products.length);
    }
    }

}

