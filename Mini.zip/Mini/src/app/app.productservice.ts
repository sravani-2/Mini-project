import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()

export class ProductService {
    constructor(private http: HttpClient) { }  //DI
    getAllProducts(): any {
        return this.http.get("./assets/booklist.json");
    }
}